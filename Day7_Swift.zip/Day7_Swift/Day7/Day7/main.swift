//
//  main.swift
//  Day7
//
//  Created by MacStudent on 2018-02-06.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

//$ 5000

extension Int{
    func currency() -> String{
        return "$ \(self)"
    }
}

var a: Int = 1000
print(a.currency())

var b = 1_000_00.00
print(b)



