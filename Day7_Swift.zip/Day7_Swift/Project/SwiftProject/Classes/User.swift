//
//  User.swift
//  SwiftProject
//
//  Created by MacStudent on 2018-02-06.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class userid
    {
        private var userId: Int?
        private var password: String?
        private var loginStatus: String?
    
    init() {
        self.userId = 1
        self.password = "pass"
        self.loginStatus = "in"
        
        }
    
    func verifyLogin() -> Bool{
        if userId == 1 && password == "pass" && loginStatus == "in"{
            print("Login Succesfull")
        }
        return true
    }
}
