//
//  ShippingInfo
//  SwiftProject
//
//  Created by MacStudent on 2018-02-06.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class shippingInfo{
    var shippingId: Int?
    var shippingType: String?
    var shippingCost: Int?
    var shippingRegionId: Int?
    
}
