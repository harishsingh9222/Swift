//
//  Customer.swift
//  SwiftProject
//
//  Created by MacStudent on 2018-02-06.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class customer{
    var customerName: String?
    var address: String?
    var email: String?
    var creditCardInfo: String?
    var shippingInfo: String?
    
}
