//
//  OrderDetails.swift
//  SwiftProject
//
//  Created by MacStudent on 2018-02-06.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class orderDetails{
    var orderId: Int?
    var productId: Int?
    var productName: String?
    var quantity: Int?
    var unitCost: Float?
    var subtotal: Float?
    
    func clacPrice(){
        
    }
}
