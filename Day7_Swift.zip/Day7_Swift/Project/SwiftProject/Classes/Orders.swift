//
//  Orders.swift
//  SwiftProject
//
//  Created by MacStudent on 2018-02-06.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class orders{
    var orderId: Int?
    var dateCreated: String?
    var dateShipped: String?
    var customerName: String?
    var customerId: String?
    var status: String?
    var shippingId: String?
    
    func placeOrder() {
    }
}
