//
//  Manufacturer.swift
//  c0727944_Exam1_MAD3004
//
//  Created by MacStudent on 2018-02-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Manufacturer: IDisplay{
    
    var manufacturerId: Int?
    var manufacturerName: String?
    

    func manufac(manufacturerId: Int, manufacturerName: String){
        self.manufacturerId = manufacturerId
        self.manufacturerName = manufacturerName
    }
    
    func display() {
        print(self.manufacturerId!, self.manufacturerName!)
    }
}
