//
//  Order.swift
//  c0727944_Exam1_MAD3004
//
//  Created by MacStudent on 2018-02-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Order
{
    var Order_Id: Int?
    var Order_Date: Date?
    var Product_Array: [Product]?
    var Order_Total: Double?


}
