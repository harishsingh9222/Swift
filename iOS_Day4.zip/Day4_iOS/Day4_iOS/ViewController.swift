//
//  ViewController.swift
//  Day4_iOS
//
//  Created by MacStudent on 2018-02-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
   
    @IBOutlet weak var myActivityIndicatior: UIActivityIndicatorView!
    @IBOutlet weak var myProgressBar: UIProgressView!
    @IBOutlet weak var lblProgressDisplay: UILabel!
    
    var timer = Timer()
    var seconds = 10
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector (showProgress), userInfo: nil, repeats: true)
        myActivityIndicatior.hidesWhenStopped = true
    }
    
    @objc func showProgress(){
        seconds -= 1
        myProgressBar.progress += 0.10
        lblProgressDisplay.text = "\(Int(myProgressBar.progress * 10))%"
        if (seconds == 0){
            timer.invalidate()
            myActivityIndicatior.stopAnimating()
        }
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet weak var myimageView: UIImageView!
    @IBAction func mySegmentChange(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 {
            myimageView.image = UIImage(named: "DuckMinion.png")
        }else if sender.selectedSegmentIndex == 1 {
            myimageView.image = UIImage(named: "EvilMinion.png")
        }else if sender.selectedSegmentIndex == 2 {
            myimageView.image = UIImage(named: "Minion.png")
        }
    }

    @IBAction func myStepper(_ sender: UIStepper) {
        print(sender.value)
    }
    
    
    
}
