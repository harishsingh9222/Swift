//
//  FullTimeFaculty.swift
//  Aaj Ka Project
//
//  Created by MacStudent on 2018-02-05.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class FullTimeFaculty: Faculty{
    var salary: Double?
    
    override func display() {
        print (self.id!, self.name!, self.salary!)
    }
}
