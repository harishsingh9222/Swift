//
//  main.swift
//  Aaj Ka Project
//
//  Created by MacStudent on 2018-02-05.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Protocol Example")

var f1 = Faculty()
f1.setData(id: 1, name: "Harish")
f1.display()


var ft1 = FullTimeFaculty()
ft1.id = 2
ft1.name = "Full Time Faculty Name"
ft1.salary = 1000
ft1.display()

print("-------------- After Protocol Refrence --------------")

var ref: iDisplay
ref = f1
ref.display()
ref = ft1
ref.display()
