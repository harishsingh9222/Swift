//
//  ViewController.swift
//  ProjectParking
//
//  Created by MacStudent on 2018-02-22.
//  Copyright © 2018 Harish. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
 
    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBAction func switchRemember(_ sender: UISwitch) {
        
    }
    @IBAction func btnLogin(_ sender: UIButton) {
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func btnSignUp(_ sender: UIButton) {
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

