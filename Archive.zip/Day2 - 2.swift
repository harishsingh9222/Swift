//: Playground - noun: a place where people can play

import UIKit

print("Dictionary Tutorial")
print("-------------")
print("-------------")

var a = ["Name":"Harish", "City":"Toronto"]

for (k,v) in a {
    print("\(k)-->\(v)")
}
print("-------------")

a["Job"] = "Software Developer"

print("-------------")
for k in a.keys{
    print("\(k)")
}



print("-------------")

for v in a.values{
    print("\(v)")
}
print("-------------")
print("Update Value")
print("-------------")
if var ov = a.updateValue("Paris", forKey: "City"){
    print ("Old values for city is \(ov)")
}
print("-------------")

var keys = [String](a.keys)
for i in keys{
    print(i)
}

