//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var a = [1, 2, 3, 4, 5, 6]
//print (a[2])
//a.append(600)
//print (a[5])

/*var b = [1000, 2000, 3000]
a = a + b

for i in a{
    //print(i)
}

var c: [Int]!
//c?.append(10)
print (c?.count ?? 0)*/



// Array Slicing
for i in a[2..<5]{
    print (i)
}

print ("----------")


var e = a[2...5]
for j in e{
    print (j)
}

print ("----------")
print (e[2])




print ("----------")
e[2] = 9000

print (e[2])
print (a[2])

print ("----------")

var threeDoubles = Array(repeating: 1.0, count: 3)
print (threeDoubles)

for (I,V) in a.enumerated(){
    print("Index : \(I)-->\(V)")
}
