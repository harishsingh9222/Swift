//
//  ViewController.swift
//  iOS_Day3
//
//  Created by MacStudent on 2018-02-22.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
  
    @IBOutlet weak var btnChange: UIButton!
    @IBOutlet weak var switchOne: UISwitch!
    @IBOutlet weak var myTextField: UITextField!
    @IBOutlet weak var myImage: UIImageView!
    @IBOutlet weak var sliderOne: UISlider!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myImage.image = UIImage(named: "lion.png")
    }
    
    
    @IBAction func mySwitchtapped(_ sender: UISwitch) {
        if sender.isOn{
            myTextField.text = "The Switch is ON"
            myImage.image = UIImage(named: "panda.png")
        }else{
            myTextField.text = "The Switch is OFF"
            myImage.image = UIImage(named: "lion.png")
        }
    }
    
    @IBAction func btnClicked(_ sender: UIButton) {
        if switchOne.isOn{
            myTextField.text = "The Switch is Off"
            switchOne.setOn(false, animated: true)
            myImage.image = UIImage(named: "panda.png")
            
        }else{
            myTextField.text = "The Switch is ON"
            switchOne.setOn(true, animated: true)
            myImage.image = UIImage(named: "lion.png")
        }
    }
    
    @IBAction func sliderChange(_ sender: UISlider) {
        myTextField.text = String(Int(sender.value))
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }


}

