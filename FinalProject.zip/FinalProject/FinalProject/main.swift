//
//  main.swift
//  FinalProject
//
//  Created by MacStudent on 2018-02-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

let customer = Customer()
print("Enter customer name:")
let customerName = readLine()
print("Enter customer address:")
let address = readLine()
print("Enter customer email:")
let email = readLine()
print("Enter customer credit card info:")
let creditcard = readLine()
print("Enter customer shipping info:")
let shipping = readLine()

customer.register(_name: customerName!, _address: address!, _email: email!, _creditCardInfo: creditcard!, _shippingInfo: shipping!)
print(customer.displayData())
print("////////////////////////******Enter shopping detail******///////////////////")
let cart = ShopingCart.init()
print("Enter card id:")
let cardid = readLine()
print("Enter card ProductId:")
let productid = readLine()
print("Quantity:")
let quality = readLine()
print("date:")
let date = readLine()

cart.addCardItem(_cartId: Int(cardid!)!, _productId: Int(productid!)!, _quantity: Int(quality!)!, _date: Int(date!)!)
print(cart.displayData())
