//
//  Protocol.swift
//  FinalProject
//
//  Created by MacStudent on 2018-02-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

protocol IDisplay {
    func displayData() -> String
}
