//
//  Customer.swift
//  FinalProject
//
//  Created by MacStudent on 2018-02-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Customer :IDisplay {
    
    var customerName: String!
    var address : String!
    var email:String!
    var creditCardInfo:String!
    var shippingInfo:String!
    
    func register(_name : String,_address : String, _email: String, _creditCardInfo : String, _shippingInfo : String) {
        customerName = _name
        address = _address
        email = _email
        creditCardInfo = _creditCardInfo
        shippingInfo = _shippingInfo
    }
    
    func displayData() -> String {
        return "CustomerName:\(customerName!) \n Address:\(address!) \n Email:\(email!) \n CrediCardInfo:\(creditCardInfo!) \n ShippinInfo:\(shippingInfo!)"
    }
    
}
