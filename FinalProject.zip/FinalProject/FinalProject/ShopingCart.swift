//
//  ShopingCart.swift
//  FinalProject
//
//  Created by MacStudent on 2018-02-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class ShopingCart : Customer {
    
    var cartId : Int!
    var productId : Int!
    var quantity : Int!
    var dateAdded : Int!
    
    
    func addCardItem(_cartId : Int, _productId: Int, _quantity:Int, _date : Int)  {
        cartId = _cartId
        productId = _productId
        quantity = _quantity
        dateAdded = _date
    }
    
    func updateQuantity( _quantity:Int)  {
        quantity = _quantity
    }
    
    func viewCardDetails()  {
        print("Card Id:\(cartId!) \n ProductId:\(productId!)\n Quantity :\(quantity!) \n DateAdded:\(dateAdded!)" )
    }
    
    override func displayData() -> String {
        return "Card Id:\(cartId!) \n ProductId:\(productId!)\n Quantity :\(quantity!) \n DateAdded:\(dateAdded!)"
    }
    
}
