//
//  SecondViewController.swift
//  FirstExample
//
//  Created by MacStudent on 2018-02-21.
//  Copyright © 2018 moxDroid. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
         self.title = "SecondView Controller"
    }

    @IBAction func btnNext(_ sender: UIButton) {
        
        let myStoryBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let nextVC = myStoryBoard.instantiateViewController(withIdentifier: "thirdVC") as! ThirdViewController
        self.present(nextVC, animated: true, completion: nil)
        nextVC.strHello = "Hello World"
      //  nextVC.goData(str: "Function Call")
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
