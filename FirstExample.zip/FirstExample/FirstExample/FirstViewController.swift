//
//  ViewController.swift
//  FirstExample
//
//  Created by moxDroid on 2017-10-12.
//  Copyright © 2017 moxDroid. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    @IBOutlet weak var txtUserEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func loginClick(_ sender: UIButton) {
        
        if(txtUserEmail.text == "admin@gmail.com" && txtPassword.text == "admin123")
        {
            print("Hello, My First Click : ", txtUserEmail.text! )
        }
        else{
            print("User Email / Password incorrect")
        }
    }
    
    func validateUser(){
        if(txtUserEmail.text == "admin@gmail.com" && txtPassword.text == "admin123"){
            print ("Hello, first click :", txtUserEmail.text)
            
            let myStoryBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let nextVC = myStoryBoard.instantiateViewController(withIdentifier: "secondVC") as! SecondViewController
            self.present(nextVC, animated: true, completion: nil)
        }
        else{
            // Alert Popup
            let alert = UIAlertController(title:"Beware", message:"Welcome guys", preferredStyle: UIAlertControllerStyle.actionSheet)
            
            // Ok Button
            let alertOk = UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: {_ in print("Alert Ok")})
            alert.addAction(alertOk)
            
            // Cancel Button
            let alertCancel = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default, handler: nil)
            alert.addAction(alertCancel)
            
            // Retry Button
            let alertRetry = UIAlertAction(title: "Ignore", style: UIAlertActionStyle.destructive, handler: nil)
            alert.addAction(alertRetry)
            
            // Present Alert Dialog to the User
            self.present(alert, animated: true, completion: nil)
        }
    }
}

