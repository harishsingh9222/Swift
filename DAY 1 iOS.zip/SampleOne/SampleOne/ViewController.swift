//
//  ViewController.swift
//  SampleOne
//
//  Created by MacStudent on 2018-02-20.
//  Copyright © 2018 xDev. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblAge: UILabel!
    @IBOutlet weak var lblSubject: UILabel!
    @IBOutlet weak var lblCollege: UILabel!
    @IBOutlet weak var lblTeacher: UILabel!
    @IBOutlet weak var txtBox: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       
        lblName.text = "Harish"
        lblAge.text = "23"
        lblSubject.text = "iOS Programming"
        lblTeacher.text = "Mr. Pritesh Patel"
        lblCollege.text = "Lambton College"
    }
    @IBAction func btnClick(_ sender: UIButton) {
        /*lblName.text = "Harish Singh"
        lblAge.text = "24"
        lblSubject.text = "iOS_Programming"
        lblTeacher.text = "Mr.Pritesh Patel"
        lblCollege.text = "Lambton College, Toronto"*/
        
        txtBox.text = "Se you'll Tommorow"
        txtBox.text = lblName.text
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

